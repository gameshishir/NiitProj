package com.wave14.c2s1.H2GetPostsprint;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class H2GetPostsprintApplicationTests {

	@Test
	void contextLoads() {
	}

}
