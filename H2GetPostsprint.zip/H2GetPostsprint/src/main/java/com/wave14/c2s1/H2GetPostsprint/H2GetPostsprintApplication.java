package com.wave14.c2s1.H2GetPostsprint;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class H2GetPostsprintApplication {

	public static void main(String[] args) {
		SpringApplication.run(H2GetPostsprintApplication.class, args);
	}

}
