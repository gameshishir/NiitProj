package com.wave14.c2s1.H2GetPost;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class H2GetPostApplicationTests {

	@Test
	void contextLoads() {
	}

}
