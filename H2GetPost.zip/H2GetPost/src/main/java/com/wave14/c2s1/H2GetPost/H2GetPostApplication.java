package com.wave14.c2s1.H2GetPost;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class H2GetPostApplication {

	public static void main(String[] args) {
		SpringApplication.run(H2GetPostApplication.class, args);
	}

}
