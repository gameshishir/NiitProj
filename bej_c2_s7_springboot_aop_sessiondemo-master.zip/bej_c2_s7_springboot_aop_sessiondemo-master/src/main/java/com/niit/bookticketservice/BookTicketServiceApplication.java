package com.niit.bookticketservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookTicketServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookTicketServiceApplication.class, args);
	}

}
